# Supabase-Einrichtung für Mein Dienstplan

## 1. Projekt
Kostenloses Supabase-Projekt anlegen und unter Settings → API die
Project URL und den Publishable Key kopieren.

## 2. Anonyme Anmeldung
Authentication → Sign In / Providers → Anonymous Sign-Ins aktivieren.
Die App nutzt dadurch keinen Benutzer-Login.

## 3. Datenbank
Den Inhalt von `migrations/0001_init.sql` im Supabase SQL Editor ausführen.

## 4. Web-Push-Schlüssel
Du brauchst ein VAPID-Schlüsselpaar. Erzeuge es lokal mit:
`npx web-push generate-vapid-keys`

Den PUBLIC Key kommt in `.env` als `VITE_VAPID_PUBLIC_KEY`.
Den PUBLIC und PRIVATE Key werden zusätzlich als Edge-Function-Secrets gesetzt.

Wichtig: Der PRIVATE Key darf niemals ins GitHub-Repository.

## 5. Edge Function
Mit Supabase CLI:
`supabase login`
`supabase link --project-ref DEIN_PROJECT_REF`
`supabase functions deploy send-evening-reminders`

Secrets:
`supabase secrets set VAPID_PUBLIC_KEY="..." VAPID_PRIVATE_KEY="..."`

## 6. Scheduler 20:30
Supabase Cron kann Edge Functions regelmäßig aufrufen. In der aktuellen Version
wird die Function alle 15 Minuten aufgerufen und prüft selbst die lokale Zeit
des jeweiligen Geräts. Dadurch funktioniert Europe/Berlin auch bei Sommer-/Winterzeit.

Beispiel (Project URL und Publishable Key über Vault einsetzen):

select cron.schedule(
  'dienstplan-evening-reminders',
  '*/15 * * * *',
  $$
  select net.http_post(
    url := 'https://DEIN_PROJECT_REF.supabase.co/functions/v1/send-evening-reminders',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'apikey','DEIN_PUBLISHABLE_KEY'
    ),
    body := '{}'::jsonb
  ) as request_id;
  $$
);

Für eine saubere Produktion solltest du URL und Key in Supabase Vault speichern,
statt sie im SQL zu hinterlegen.

## 7. Frontend
`.env.example` nach `.env` kopieren und die drei Werte eintragen.
Danach:
`npm install`
`npm run build`

Für GitHub Pages ist `base: '/mein-dienstplan/'` bereits gesetzt.
