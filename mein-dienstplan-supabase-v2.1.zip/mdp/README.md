# Mein Dienstplan 2.0 – Supabase

Kostenlose Alternative zum Firebase-Backend.

Enthalten:
- Foto/OCR für Dienstpläne
- manuelle Schichterfassung
- Abteilung / Ösi-Pause
- Supabase-Datenbank mit RLS
- anonyme Anmeldung ohne Passwort
- Web-Push
- Server-Scheduler für die Vorabend-Erinnerung
- Kalender-Export als `.ics`
- iPhone-PWA / GitHub Pages

## Wichtig
Die ZIP ist bewusst ohne geheime Supabase- oder VAPID-Schlüssel.
Die Schlüssel werden nach dem Erstellen des kostenlosen Supabase-Projekts
eingetragen. Der VAPID Private Key gehört ausschließlich als Secret in Supabase.

Siehe `supabase/README.md`.
