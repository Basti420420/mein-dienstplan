// Firebase is intentionally not used in this version.
// Backend: Supabase + Supabase Edge Functions.
